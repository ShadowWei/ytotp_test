sourcefile = "/home/hongwei/Desktop/ytopt-master/OpenMP_benchmark/correlation/correlation.c"
sourcedir = "/home/hongwei/Desktop/ytopt-master/OpenMP_benchmark"
outputdir = "/home/hongwei/Desktop/ytopt-master/experiments/exp-6"
compileoptions = ""
